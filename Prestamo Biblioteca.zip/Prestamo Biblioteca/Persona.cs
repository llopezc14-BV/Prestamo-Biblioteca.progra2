namespace PrestamosBiblioteca;

public class Persona
{
    public string Nombre { get; set; } = string.Empty;
    public string Correo { get; set; } = string.Empty;
    public string Telefono { get; set; } = string.Empty;

    public virtual string ObtenerInformacion()
    {
        return $"Nombre: {Nombre}, Correo: {Correo}, Teléfono: {Telefono}";
    }
}