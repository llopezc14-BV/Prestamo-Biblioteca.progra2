using System;

namespace PrestamosBiblioteca;

public class Prestamo
{
    public int Id { get; set; }
    public int LectorId { get; set; }
    public int LibroId { get; set; }
    public DateTime FechaPrestamo { get; set; }
    public DateTime? FechaDevolucion { get; set; }
    public DateTime? FechaLimite { get; set; }
    public bool EstaActivo { get; set; }

    public Prestamo() { }

    public Prestamo(int lectorId, int libroId, DateTime fechaPrestamo, DateTime? fechaLimite)
    {
        LectorId = lectorId;
        LibroId = libroId;
        FechaPrestamo = fechaPrestamo;
        FechaLimite = fechaLimite;
        EstaActivo = true;
    }
}