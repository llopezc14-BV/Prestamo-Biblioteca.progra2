﻿using System;

using PrestamosBiblioteca.Aplicacion;
using PrestamosBiblioteca.Persistencia;
// Usamos el namespace principal del proyecto
namespace PrestamosBiblioteca;

class Program
{
    static void Main(string[] args)
    {

        var repositorio = new RepositorioBiblioteca("Data Source=biblioteca.db");
        var menu = new MenuBiblioteca(repositorio);
        menu.Ejecutar();
        
    }
}