namespace PrestamosBiblioteca;

public class Autor
{
    public int ID { get; set; }
    public string Nombre { get; set; } = string.Empty;
}