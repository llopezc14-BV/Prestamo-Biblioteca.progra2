namespace PrestamosBiblioteca;

public class Lector : Persona
{
    public int Id { get; set; }
    public string Codigo { get; set; } = string.Empty;

    public Lector() { }

    public Lector(string codigo, string nombre, string correo, string telefono)
    {
        Codigo = codigo;
        Nombre = nombre;
        Correo = correo;
        Telefono = telefono;
    }
}