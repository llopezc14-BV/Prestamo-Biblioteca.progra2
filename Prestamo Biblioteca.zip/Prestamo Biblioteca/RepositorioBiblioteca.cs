using System.Data;
using Microsoft.Data.Sqlite;

namespace PrestamosBiblioteca.Persistencia;

internal sealed class RepositorioBiblioteca
{
    private readonly string _cadenaConexion;

    public RepositorioBiblioteca(string cadenaConexion)
    {
        _cadenaConexion = cadenaConexion;
        InicializarBaseDeDatos();
    }

    // --- LECTORES ---
    public DataTable ObtenerLectores() => Consultar(
        "SELECT Id, Codigo, Nombre, Correo, Telefono FROM Lectores ORDER BY Nombre;");

    public void CrearLector(object lector) => Ejecutar(
        "INSERT INTO Lectores (Nombre) VALUES ('Lector Nuevo');");

    public void ActualizarLector(object a, object b = null) { }

    public void EliminarLector(object id) { }

    // --- LIBROS ---
    public DataTable ObtenerLibros() => Consultar(
        "SELECT Isbn, Titulo, Autor, Anio FROM Libros ORDER BY Titulo;");

    public void CrearLibro(object libro) => Ejecutar(
        "INSERT INTO Libros (Titulo) VALUES ('Libro Nuevo');");

    public void ActualizarLibro(object a, object b = null) { }

    public void EliminarLibro(object id) { }

    // --- PRÉSTAMOS ---
    public DataTable ObtenerPrestamos() => Consultar(
        "SELECT Id, CodigoLector, IsbnLibro, FechaPrestamo, FechaDevolucion FROM Prestamos ORDER BY Id DESC;");

    public void CrearPrestamo(object prestamo) { }

    public void ActualizarPrestamo(object a, object b = null, object c = null, object d = null, object e = null) { }

    public void RegistrarDevolucion(object a, object b = null) { }

    public void EliminarPrestamo(object id) { }

    // --- MÉTODOS AUXILIARES ---
    private DataTable Consultar(string sql)
    {
        using var conexion = AbrirConexion();
        using var comando = new SqliteCommand(sql, conexion);
        using var lector = comando.ExecuteReader();
        var tabla = new DataTable();
        tabla.Load(lector);
        return tabla;
    }

    private void Ejecutar(string sql)
    {
        using var conexion = AbrirConexion();
        using var comando = new SqliteCommand(sql, conexion);
        comando.ExecuteNonQuery();
    }

    private SqliteConnection AbrirConexion()
    {
        var conexion = new SqliteConnection(_cadenaConexion);
        conexion.Open();
        return conexion;
    }

    private void InicializarBaseDeDatos()
    {
        using var conexion = AbrirConexion();
        using var comando = conexion.CreateCommand();
        comando.CommandText = @"
            CREATE TABLE IF NOT EXISTS Lectores (
                Id INTEGER PRIMARY KEY AUTOINCREMENT,
                Codigo TEXT,
                Nombre TEXT NOT NULL,
                Correo TEXT,
                Telefono TEXT
            );

            CREATE TABLE IF NOT EXISTS Libros (
                Isbn TEXT PRIMARY KEY,
                Titulo TEXT NOT NULL,
                Autor TEXT,
                Anio INTEGER
            );

            CREATE TABLE IF NOT EXISTS Prestamos (
                Id INTEGER PRIMARY KEY AUTOINCREMENT,
                CodigoLector TEXT,
                IsbnLibro TEXT,
                FechaPrestamo TEXT,
                FechaDevolucion TEXT
            );";
        comando.ExecuteNonQuery();
    }
}